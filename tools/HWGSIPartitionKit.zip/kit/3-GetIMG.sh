#!/sbin/sh
echo "HWGSIPartition - Part 3/5"

adb pull "/sdcard/Documents/HW" 